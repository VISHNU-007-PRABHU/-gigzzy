self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "19c773b916768f6b7f2a125dbd80f9d2",
    "url": "/index.html"
  },
  {
    "revision": "02979daf47972dbab082",
    "url": "/static/css/8.bcb7de5e.chunk.css"
  },
  {
    "revision": "b8b28ac5c4da948fb9b4",
    "url": "/static/css/main.4f72ba9a.chunk.css"
  },
  {
    "revision": "788dd87235f8b6aebfa7",
    "url": "/static/js/0.f7a1ead0.chunk.js"
  },
  {
    "revision": "233d5073788a7d44436e",
    "url": "/static/js/1.8a5b0b19.chunk.js"
  },
  {
    "revision": "d5fe32ec0a3cdf0b1cb2",
    "url": "/static/js/10.76fe5ba0.chunk.js"
  },
  {
    "revision": "f12eb76d3327d974459e",
    "url": "/static/js/11.db240adb.chunk.js"
  },
  {
    "revision": "508ca5db0e4894e34762",
    "url": "/static/js/12.a1405381.chunk.js"
  },
  {
    "revision": "fe7cf352456cf1318b55",
    "url": "/static/js/13.bad86169.chunk.js"
  },
  {
    "revision": "20e1e1f8b58f46ec39bf",
    "url": "/static/js/2.bb6e2edc.chunk.js"
  },
  {
    "revision": "ca4eae90f9755c6fe777",
    "url": "/static/js/3.8c1876f0.chunk.js"
  },
  {
    "revision": "922069f53e2d2fa2b5f5",
    "url": "/static/js/4.c62d29bd.chunk.js"
  },
  {
    "revision": "2f26ab4ef62f521e95f3",
    "url": "/static/js/5.3e46c7cc.chunk.js"
  },
  {
    "revision": "02979daf47972dbab082",
    "url": "/static/js/8.1c58d3a8.chunk.js"
  },
  {
    "revision": "6e445df22c642af8b419",
    "url": "/static/js/9.8d1b5cc5.chunk.js"
  },
  {
    "revision": "b8b28ac5c4da948fb9b4",
    "url": "/static/js/main.76954aba.chunk.js"
  },
  {
    "revision": "3c330164f1f14fae8d33",
    "url": "/static/js/runtime~main.80c3e1ef.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "b01d3874df5e40b2d6a44a50e52b8231",
    "url": "/static/media/handyman.b01d3874.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);